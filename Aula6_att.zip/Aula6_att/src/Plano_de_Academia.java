import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import net.miginfocom.swing.MigLayout;
import javax.swing.JLabel;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

public class Plano_de_Academia extends JFrame {
	double valorf = 0;
	double valorm = 0;
	double duracao = 0;
	double freq = 0;
	
	boolean tp = true;
	boolean np = true;

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Plano_de_Academia frame = new Plano_de_Academia();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	@SuppressWarnings("unused")
	public Plano_de_Academia() {
		
		
		setTitle("Plano de Academia");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new MigLayout("", "[grow][][][grow][][][][][][grow]", "[grow][][][][7.00][][][][][][grow]"));
		
		JLabel lblNewLabel = new JLabel("Cadastro de Cliente - Academia TREINO FIT");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 16));
		contentPane.add(lblNewLabel, "cell 2 1 7 1,alignx left");
		
		JLabel lblNewLabel_5 = new JLabel("Nome:");
		contentPane.add(lblNewLabel_5, "cell 1 2,alignx trailing");
		
		textField = new JTextField();
		contentPane.add(textField, "cell 2 2 7 1,growx");
		textField.setColumns(10);
		
		JLabel lblNewLabel_6 = new JLabel("Telefone:");
		contentPane.add(lblNewLabel_6, "cell 1 3,alignx trailing");
		
		textField_1 = new JTextField();
		contentPane.add(textField_1, "cell 2 3 7 1,growx");
		textField_1.setColumns(10);
		
		
		JLabel lblNewLabel_2 = new JLabel("Tipo de Plano:");
		contentPane.add(lblNewLabel_2, "cell 1 5,alignx right");
		
		ButtonGroup planobuttongroup = new ButtonGroup();
		
		JComboBox tipoplano = new JComboBox();
		tipoplano.setModel(new DefaultComboBoxModel(new String[] {"Básico", "Intermediário", "Premium"}));
		contentPane.add(tipoplano, "cell 3 5 6 1,growx");
		
		JLabel lblNewLabel_3 = new JLabel("Duração:");
		contentPane.add(lblNewLabel_3, "cell 1 6,alignx right");
		
		ButtonGroup duracaobuttongroup = new ButtonGroup();
		
		JComboBox dura = new JComboBox();
		dura.setModel(new DefaultComboBoxModel(new String[] {"Mensal", "Semestral", "Anual"}));
		contentPane.add(dura, "cell 3 6 6 1,growx");
		
		JLabel lblNewLabel_4 = new JLabel("Frequência mensal:");
		contentPane.add(lblNewLabel_4, "cell 1 7,alignx right");
		
		ButtonGroup freqbuttongroup = new ButtonGroup();
		
		
		JComboBox frequencia = new JComboBox();
		frequencia.setModel(new DefaultComboBoxModel(new String[] {"2x por semana", "3x por semana", "5x por semana"}));
		contentPane.add(frequencia, "cell 3 7 6 1,growx");
		


		JLabel lblNewLabel_1 = new JLabel("Valor Final: ");
		contentPane.add(lblNewLabel_1, "cell 5 9 2 1,alignx center");
		

		JButton btnNewButton = new JButton("Calcular");
		btnNewButton.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				
				//checks
				String f = (String) frequencia.getSelectedItem();
				String t = (String) tipoplano.getSelectedItem();
				String d = (String) dura.getSelectedItem();
				
				if (f == "2x por semana") {
					freq = 0;
				}else if (f == "3x por semana") {
					freq = 20;
				}else if (f == "5x por semana") {
					freq = 50;
				}
				if (t == "Básico") {
					valorm = 80;
				}else if (t == "Intermediário") {
					valorm = 120;
				}else if (t == "Premium") {
					valorm = 180;
				}
				if (d == "Mensal") {
					duracao = 0;
				}else if (d == "Semestral") {
					duracao = 10;
				}else if (d == "Anual") {
					duracao = 20;
				}
				
						if(textField.getText().isBlank()) {
							np = false;
						}
						if(textField_1.getText().isBlank()) {
							tp = false;
						}
				
				//calculate
				if(np && tp) {
				 valorf = valorm + ((valorm/100) * freq);
				 valorf = valorf - ((valorf/100) * duracao);
				 
				 lblNewLabel_1.setText("Valor Final: " + valorf);
				} else {
					lblNewLabel_1.setText("Preencha todos os campos");
				}
			}
		});
		
		contentPane.add(btnNewButton, "cell 2 9 2 1,alignx center");
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
