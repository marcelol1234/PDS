import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import net.miginfocom.swing.MigLayout;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;

public class JanelaPesssoa extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtNome;
	private JTextField txtCPF;
	private JTextField txtIdade;
	private JTable table;
	
	ArrayList<Pessoa> bancoDadoslistaPessoa = new ArrayList<Pessoa>();
	private JTextField textIdade;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					JanelaPesssoa frame = new JanelaPesssoa();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public JanelaPesssoa() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 556, 466);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new MigLayout("", "[][][grow][grow][][]", "[][][][][grow][][][]"));
		
		JLabel lblNewLabel = new JLabel("Nome:");
		contentPane.add(lblNewLabel, "cell 1 0,alignx trailing");
		
		txtNome = new JTextField();
		contentPane.add(txtNome, "cell 2 0 2 1,growx");
		txtNome.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("CPF:");
		contentPane.add(lblNewLabel_1, "cell 1 1,alignx trailing");
		
		JLabel lblNewLabel_1_1 = new JLabel("Idade:");
		contentPane.add(lblNewLabel_1_1, "cell 1 2,alignx trailing");
		
		txtCPF = new JTextField();
		contentPane.add(txtCPF, "cell 2 1 2 1,growx");
		txtCPF.setColumns(10);
		
		JButton btnNewButton = new JButton("Adicionar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String nome = txtNome.getText();
				String cpf = txtCPF.getText();
				String idade = txtIdade.getText();
				
				Pessoa p = new Pessoa(nome, cpf, idade);
				bancoDadoslistaPessoa.add(p);
				table.setModel(new PessoaTableModel(bancoDadoslistaPessoa));
				
				txtNome.setText("");
				txtCPF.setText("");
				txtIdade.setText("");
				
			}
		});
		
		
		
		txtIdade = new JTextField();
		txtIdade.setColumns(10);
		contentPane.add(txtIdade, "cell 2 2 2 1,growx");
		contentPane.add(btnNewButton, "cell 1 3");
		
		JButton btnNewButton_1 = new JButton("Remover");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				int linhaSelecionada = table.getSelectedRow();
				bancoDadoslistaPessoa.remove(linhaSelecionada);
				table.setModel(new PessoaTableModel(bancoDadoslistaPessoa));

				
				
			}
		});
		contentPane.add(btnNewButton_1, "cell 2 3");
		
		JScrollPane scrollPane = new JScrollPane();
		contentPane.add(scrollPane, "cell 1 4 4 4,grow");
		
		table = new JTable();
		table.setModel(new PessoaTableModel());
		scrollPane.setViewportView(table);

	}

}
