
public class Pessoa {
	private String nome, cpf, idade;

	public Pessoa(String nome, String cpf, String idade) {
		this.nome = nome;
		this.cpf = cpf;
		this.idade = idade;
	}
	
	
	
	public String getIdade() {
		return idade;
	}



	public void setIdade(String idade) {
		this.idade = idade;
	}



	public String getNome() {
		return nome;
	}

	public void setNome(String nopme) {
		this.nome = nopme;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	
	

}
