import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import net.miginfocom.swing.MigLayout;
import javax.swing.JLabel;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Plano_de_Academia extends JFrame {
	double valorf = 0;
	double valorm = 0;
	double duracao = 0;
	double freq = 0;
	boolean vp = false;
	boolean dp = false;
	boolean fp = false;
	boolean tp = false;
	boolean np = false;

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Plano_de_Academia frame = new Plano_de_Academia();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	@SuppressWarnings("unused")
	public Plano_de_Academia() {
		
		
		setTitle("Plano de Academia");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new MigLayout("", "[grow][][][][][][][][][grow]", "[grow][][][][7.00][][][][][][grow]"));
		
		JLabel lblNewLabel = new JLabel("Cadastro de Cliente - Academia TREINO FIT");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 16));
		contentPane.add(lblNewLabel, "cell 2 1 7 1,alignx left");
		
		JLabel lblNewLabel_5 = new JLabel("Nome:");
		contentPane.add(lblNewLabel_5, "cell 1 2,alignx trailing");
		
		textField = new JTextField();
		contentPane.add(textField, "cell 2 2 7 1,growx");
		textField.setColumns(10);
		
		JLabel lblNewLabel_6 = new JLabel("Telefone:");
		contentPane.add(lblNewLabel_6, "cell 1 3,alignx trailing");
		
		textField_1 = new JTextField();
		contentPane.add(textField_1, "cell 2 3 7 1,growx");
		textField_1.setColumns(10);
		
		
		JLabel lblNewLabel_2 = new JLabel("Tipo de Plano:");
		contentPane.add(lblNewLabel_2, "cell 1 5,alignx right");
	
		JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Básico");
		rdbtnNewRadioButton_2.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				valorm =  80;
				vp = true;
				
			}
		});
		contentPane.add(rdbtnNewRadioButton_2, "cell 2 5");
		
		JRadioButton rdbtnNewRadioButton_8 = new JRadioButton("Intermediário");
		contentPane.add(rdbtnNewRadioButton_8, "cell 4 5 2 1");
		rdbtnNewRadioButton_8.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				valorm =  120;
				vp = true;
			}
		});
		
		JRadioButton rdbtnNewRadioButton_5 = new JRadioButton("Premium");
		contentPane.add(rdbtnNewRadioButton_5, "cell 7 5 2 1");
		rdbtnNewRadioButton_5.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				valorm =  180;
				vp = true;
			}
		});
		
		ButtonGroup planobuttongroup = new ButtonGroup();
		planobuttongroup.add(rdbtnNewRadioButton_2);
		planobuttongroup.add(rdbtnNewRadioButton_8);
		planobuttongroup.add(rdbtnNewRadioButton_5);
		
		JLabel lblNewLabel_3 = new JLabel("Duração:");
		contentPane.add(lblNewLabel_3, "cell 1 6,alignx right");
		
		JRadioButton rdbtnNewRadioButton_1 = new JRadioButton("Mensal");
		contentPane.add(rdbtnNewRadioButton_1, "cell 2 6");
		rdbtnNewRadioButton_1.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				duracao =  0;
				dp = true;
			}
		});
		
		JRadioButton rdbtnNewRadioButton_7 = new JRadioButton("Semestral");
		contentPane.add(rdbtnNewRadioButton_7, "cell 4 6 2 1");
		rdbtnNewRadioButton_7.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				duracao =  10;
				dp = true;
			}
		});
		
		JRadioButton rdbtnNewRadioButton_4 = new JRadioButton("Anual");
		contentPane.add(rdbtnNewRadioButton_4, "cell 7 6 2 1");
		rdbtnNewRadioButton_4.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				duracao =  20;
				dp = true;
			}
		});
		
		ButtonGroup duracaobuttongroup = new ButtonGroup();
		duracaobuttongroup.add(rdbtnNewRadioButton_1);
		duracaobuttongroup.add(rdbtnNewRadioButton_4);
		duracaobuttongroup.add(rdbtnNewRadioButton_7);
		
		JLabel lblNewLabel_4 = new JLabel("Frequência mensal:");
		contentPane.add(lblNewLabel_4, "cell 1 7,alignx right");
		
		JRadioButton rdbtnNewRadioButton = new JRadioButton("2x por semana");
		contentPane.add(rdbtnNewRadioButton, "cell 2 7");
		rdbtnNewRadioButton.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				freq =  0;
				fp = true;
			}
		});
		
		JRadioButton rdbtnNewRadioButton_6 = new JRadioButton("3x por semana");
		contentPane.add(rdbtnNewRadioButton_6, "cell 4 7 2 1");
		rdbtnNewRadioButton_6.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				freq =  20;
				fp = true;
			}
		});
		
		JRadioButton rdbtnNewRadioButton_3 = new JRadioButton("5x por semana");
		contentPane.add(rdbtnNewRadioButton_3, "cell 7 7 2 1");
		rdbtnNewRadioButton_3.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				freq =  50;
				fp = true;
			}
		});
		
		ButtonGroup freqbuttongroup = new ButtonGroup();
		freqbuttongroup.add(rdbtnNewRadioButton);
		freqbuttongroup.add(rdbtnNewRadioButton_3);
		freqbuttongroup.add(rdbtnNewRadioButton_6);
		
		if(textField.getText().length() > 0) {
			np = true;
		}
		if(textField_1.getText().length() > 0) {
			tp = true;
		}
		
		
		JLabel lblNewLabel_1 = new JLabel("Valor Final: ");
		contentPane.add(lblNewLabel_1, "cell 5 9 2 1,alignx center");

		JButton btnNewButton = new JButton("Calcular");
		btnNewButton.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				if(vp && dp && fp) {
				 valorf = valorm + ((valorm/100) * freq);
				 valorf = valorf - ((valorf/100) * duracao);
				 
				 lblNewLabel_1.setText("Valor Final: " + valorf);
				} else {
					lblNewLabel_1.setText("Preencha todos os campos");
				}
			}
		});
		
		contentPane.add(btnNewButton, "cell 2 9 2 1,alignx center");
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
