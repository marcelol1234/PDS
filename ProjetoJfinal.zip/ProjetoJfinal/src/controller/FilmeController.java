package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import model.Filme;
import model.FilmeTableModel;
import view.JanelaFilme;

public class FilmeController {
	
	private FilmeTableModel filmeModel;
	private JanelaFilme view;
	
	public FilmeController(FilmeTableModel modelo, JanelaFilme view) {
		this.filmeModel = modelo;
		this.view = view;
		
		this.view.getTable().setModel(modelo);
		this.view.getBtnAdicionar().addActionListener(e -> eventoBotaoAdicionar());
		this.view.getBtnRemover().addActionListener(e -> eventoBotaoRemover());
		this.view.getBtnAtualizar().addActionListener(e -> eventoBotaoAtualizar());
		
	}

	public void eventoBotaoRemover() {
		int linhaSelecionada = this.view.getTable().getSelectedRow();
		filmeModel.remover(linhaSelecionada);

	}
	public void eventoBotaoAtualizar() {
		int linhaSelecionada = this.view.getTable().getSelectedRow();
		String nome = this.view.getTxtNome().getText();
		int ano = Integer.parseInt(this.view.getTxtAno().getText());
		double duracao = Double.parseDouble(this.view.getTxtDuracao().getText());
		String estudio = this.view.getTxtEstudio().getText();
		int classetaria = Integer.parseInt(this.view.getTxtClassetaria().getText());
		
		Filme f = new Filme(nome, ano, duracao, estudio, classetaria);
		filmeModel.atualizarFilme(f, linhaSelecionada);
		
		this.view.getTxtNome().setText("");
		this.view.getTxtAno().setText("");
		this.view.getTxtDuracao().setText("");
		this.view.getTxtEstudio().setText("");
		this.view.getTxtClassetaria().setText("");
	}
	
	public void eventoBotaoAdicionar() {
		int linhaSelecionada = this.view.getTable().getSelectedRow();
		String nome = this.view.getTxtNome().getText();
		int ano = Integer.parseInt(this.view.getTxtAno().getText());
		double duracao = Double.parseDouble(this.view.getTxtDuracao().getText());
		String estudio = this.view.getTxtEstudio().getText();
		int classetaria = Integer.parseInt(this.view.getTxtClassetaria().getText());
		
		Filme f = new Filme(nome, ano, duracao, estudio, classetaria);
		filmeModel.adicionarFilme(f);
		
		this.view.getTxtNome().setText("");
		this.view.getTxtAno().setText("");
		this.view.getTxtDuracao().setText("");
		this.view.getTxtEstudio().setText("");
		this.view.getTxtClassetaria().setText("");
	}

}
