package view;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import net.miginfocom.swing.MigLayout;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import model.Filme;
import model.FilmeTableModel;

import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Image;

import javax.swing.ImageIcon;

public class JanelaFilme extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtNome;
	private JTextField txtAno;
	private JTable table;
	
	private JButton btnAdicionar;
	private JButton btnAtualizar;
	private JButton btnRemover;
	private JTextField txtDuracao;
	private JTextField txtEstudio;
	private JLabel lblNewLabel_4;
	private JLabel lblNewLabel_5;
	private JLabel lblNewLabel_6;
	private JButton btnNewButton;
	private JLabel lblNewLabel_7;
	private JTextField txtclassetaria;

	

	/**
	 * Create the frame.
	 */
	public JanelaFilme() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 513, 574);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 0, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new MigLayout("", "[][][][grow][grow][][]", "[][][220.00,grow][grow][][][][][][][]"));
		
		lblNewLabel_6 = new JLabel("");
		lblNewLabel_6.setFont(new Font("Tahoma", Font.PLAIN, 5));
		ImageIcon originalIcon = new ImageIcon(JanelaFilme.class.getResource("/view/download-removebg-preview.png"));
		Image originalImage = originalIcon.getImage();
		Image scaledImage = originalImage.getScaledInstance(50, 50, Image.SCALE_SMOOTH);
		lblNewLabel_6.setIcon(new ImageIcon(scaledImage));
		contentPane.add(lblNewLabel_6, "cell 1 0");
		
		lblNewLabel_5 = new JLabel("FLIX");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_5.setHorizontalAlignment(SwingConstants.CENTER);
		contentPane.add(lblNewLabel_5, "cell 3 0 2 1,alignx center,aligny center");
		
		lblNewLabel_4 = new JLabel("Cadastre seu filme:");
		contentPane.add(lblNewLabel_4, "cell 1 1");
		
		JLabel lblNewLabel = new JLabel("Nome:");
		contentPane.add(lblNewLabel, "cell 1 4,alignx trailing");
		
		txtNome = new JTextField();
		txtNome.setForeground(new Color(255, 255, 255));
		txtNome.setFont(new Font("Tahoma", Font.PLAIN, 11));
		txtNome.setBackground(new Color(0, 0, 0));
		contentPane.add(txtNome, "cell 3 4 2 1,growx");
		txtNome.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Ano:");
		contentPane.add(lblNewLabel_1, "cell 1 5,alignx trailing");
		
		txtAno = new JTextField();
		txtAno.setForeground(new Color(255, 255, 255));
		txtAno.setBackground(new Color(0, 0, 0));
		contentPane.add(txtAno, "cell 3 5 2 1,growx");
		txtAno.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Duração(minutos):");
		contentPane.add(lblNewLabel_2, "cell 1 6,alignx trailing");
		
		JScrollPane scrollPane = new JScrollPane();
		contentPane.add(scrollPane, "cell 1 2 5 2,grow");
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		txtDuracao = new JTextField();
		txtDuracao.setForeground(new Color(255, 255, 255));
		txtDuracao.setBackground(new Color(0, 0, 0));
		txtDuracao.setColumns(10);
		contentPane.add(txtDuracao, "cell 3 6 2 1,growx");
		
		JLabel lblNewLabel_3 = new JLabel("Estudio:");
		contentPane.add(lblNewLabel_3, "cell 1 7,alignx trailing");
		
		txtEstudio = new JTextField();
		txtEstudio.setForeground(new Color(255, 255, 255));
		txtEstudio.setBackground(new Color(0, 0, 0));
		txtEstudio.setColumns(10);
		contentPane.add(txtEstudio, "cell 3 7 2 1,growx");
		
		lblNewLabel_7 = new JLabel("Classificação Etária:");
		lblNewLabel_7.setHorizontalAlignment(SwingConstants.RIGHT);
		contentPane.add(lblNewLabel_7, "cell 1 8,alignx right");
		
		txtclassetaria = new JTextField();
		txtclassetaria.setForeground(Color.WHITE);
		txtclassetaria.setColumns(10);
		txtclassetaria.setBackground(Color.BLACK);
		contentPane.add(txtclassetaria, "cell 3 8 2 1,growx");
		
		btnAdicionar = new JButton("Adicionar");
		
		contentPane.add(btnAdicionar, "cell 1 9");
		
		btnRemover = new JButton("Remover");
		
		contentPane.add(btnRemover, "cell 3 9");
		
		btnAtualizar = new JButton("Atualizar");
		
		contentPane.add(btnAtualizar, "cell 4 9");

	}

	public JTextField getTxtNome() {
		return txtNome;
	}

	public JTextField getTxtAno() {
		return txtAno;
	}

	public JTable getTable() {
		return table;
	}

	public JButton getBtnAdicionar() {
		return btnAdicionar;
	}

	public JButton getBtnRemover() {
		return btnRemover;
	}

	public JPanel getContentPane() {
		return contentPane;
	}

	public JTextField getTxtDuracao() {
		return txtDuracao;
	}

	public void setTxtDuracao(JTextField txtIdade) {
		this.txtDuracao = txtDuracao;
	}

	public JTextField getTxtEstudio() {
		return txtEstudio;
	}

	public void setTxtEstudio(JTextField txtEmail) {
		this.txtEstudio = txtEstudio;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public void setTxtNome(JTextField txtNome) {
		this.txtNome = txtNome;
	}

	public void setTxtCPF(JTextField txtCPF) {
		this.txtAno = txtAno;
	}

	public void setTable(JTable table) {
		this.table = table;
	}

	public void setBtnAdicionar(JButton btnAdicionar) {
		this.btnAdicionar = btnAdicionar;
	}

	public void setBtnRemover(JButton btnRemover) {
		this.btnRemover = btnRemover;
	}

	public JTextField getTxtClassetaria() {
		return txtclassetaria;
	}

	public void setTxtClassetaria(JTextField txtclassetaria) {
		this.txtclassetaria = txtclassetaria;
	}

	public JButton getBtnAtualizar() {
		return btnAtualizar;
	}

	public void setBtnAtualizar(JButton btnAtualizar) {
		this.btnAtualizar = btnAtualizar;
	}
	
	

}
