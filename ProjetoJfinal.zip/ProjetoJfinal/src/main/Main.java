package main;

import controller.FilmeController;
import model.FilmeTableModel;
import view.JanelaFilme;

public class Main {

	public static void main(String[] args) {
		
		FilmeTableModel model = new FilmeTableModel();
		JanelaFilme view = new JanelaFilme();
		FilmeController controller = new FilmeController(model, view);
		view.setVisible(true);
		

	}

}
