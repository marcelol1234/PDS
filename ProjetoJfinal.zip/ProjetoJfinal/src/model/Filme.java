package model;

public class Filme {
	private String nome, estudio;
	int ano, classetaria;
	double duracao;

	public Filme(String nome, int ano, double duracao, String estudio, int classetaria) {
		this.nome = nome;
		this.ano = ano;
		this.duracao = duracao;
		this.estudio = estudio;
		this.classetaria = classetaria;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getAno() {
		return Integer.toString(ano);
	}

	public void setAno(int ano) {
		this.ano = ano;
	}

	public String getDuracao() {
		return Double.toString(duracao);
	}

	public void setDuracao(double duracao) {
		this.duracao = duracao;
	}

	public String getEstudio() {
		return estudio;
	}

	public void setEstudio(String estudio) {
		this.estudio = estudio;
	}

	public String getClassetaria() {
		return Integer.toString(classetaria);
	}

	public void setClassetaria(int classetaria) {
		this.classetaria = classetaria;
	}
	
	
	
	

}
