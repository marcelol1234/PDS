package model;
import java.util.ArrayList;

import javax.swing.table.AbstractTableModel;

public class FilmeTableModel extends AbstractTableModel{
	ArrayList<Filme> lista;
	
	String colunas[] = new String[] { "Nome", "Ano", "Duração", "Estudio", "Classe Etária"};
	
	public FilmeTableModel() {
		this.lista = new ArrayList();
	}
	
	public FilmeTableModel(ArrayList<Filme> lista) {
		this.lista = lista;
	}
	/**
	 * Retorna o nome da Coluna consultando a String do vetor "colunas"
	 * no índice "indice"
	 */
	@Override
	public String getColumnName(int indice) {
		return colunas[indice]; 
		
	}
	
	@Override
	public int getRowCount() {
		// TODO Auto-generated method stub
		return this.lista.size();
	}

	@Override
	public int getColumnCount() {
		// TODO Auto-generated method stub
		return this.colunas.length;
	}

	@Override
	public String getValueAt(int rowIndex, int columnIndex) {
		// TODO Auto-generated method stub
		Filme pessoa = lista.get(rowIndex);
		if(columnIndex == 0) {
			return pessoa.getNome();
		} 
		if(columnIndex ==1) {
			return pessoa.getAno();
		}
		if(columnIndex ==2) {
			return pessoa.getDuracao();
		}
		if(columnIndex ==3) {
			return pessoa.getEstudio();
		}
		
		if (columnIndex == 4) {
			return pessoa.getClassetaria();
		}
		return null;
	}

	public void remover(int linhaSelecionada) {
		lista.remove(linhaSelecionada);
		fireTableDataChanged();
		
	}

	public void adicionarFilme(Filme p) {
		lista.add(p);
		fireTableDataChanged();
		
	}
	public void atualizarFilme(Filme p, int linhaSelecionada) {
		lista.set(linhaSelecionada, p);
		fireTableDataChanged();
		
	}

	
}
