package aula2;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.FlowLayout;
import javax.swing.JProgressBar;
import javax.swing.JRadioButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Component;
import javax.swing.Box;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;

public class Aula2 extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txt;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Aula2 frame = new Aula2();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Aula2() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 700, 500);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		Component horizontalStrut = Box.createHorizontalStrut(20);
		horizontalStrut.setBounds(93, 78, 519, 342);
		contentPane.add(horizontalStrut);
		
		txt = new JTextField();
		txt.setBounds(93, 226, 519, 20);
		contentPane.add(txt);
		txt.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Numero em Fahrenheit:");
		lblNewLabel.setBounds(95, 201, 46, 14);
		contentPane.add(lblNewLabel);
		JLabel lblNewLabel_1 = new JLabel();
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setVisible(false);
		lblNewLabel_1.setBounds(163, 109, 361, 14);
		contentPane.add(lblNewLabel_1);
		
		
		JButton btnNewButton = new JButton("trasformar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double c = Double.parseDouble(txt.getText());
		double fahrenheit = (c-32)* 5.0/9.0;
		String a = String.valueOf(fahrenheit);
				
				
				lblNewLabel.setVisible(false);
				horizontalStrut.setVisible(false);
				txt.setVisible(false);
				btnNewButton.setVisible(false);
				lblNewLabel_1.setText("Numero em fahrenheit = " + a + " celcius");
				lblNewLabel_1.setVisible(true);
			}
		});
		btnNewButton.setBounds(93, 257, 519, 23);
		contentPane.add(btnNewButton);

	}
}
