import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.FlowLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JMenuBar;
import javax.swing.JMenu;

public class CalculadoraInvestimentosGrid extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField nmeses;
	private JTextField depmen;
	private JTextField jurosaomes;
	int i = 0;
	double d = 0;
	double k = 0; 

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CalculadoraInvestimentosGrid frame = new CalculadoraInvestimentosGrid();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CalculadoraInvestimentosGrid() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnNewMenu = new JMenu("Ajuda");
		menuBar.add(mnNewMenu);
		
		JLabel lblNewLabel_6 = new JLabel("Sobre");
		lblNewLabel_6.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				FormSobre form = new FormSobre();
				form.main(null);
			}
		});
		mnNewMenu.add(lblNewLabel_6);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new GridLayout(5, 2, 0, 0));
		
		JLabel lblNewLabel_1 = new JLabel("Depósito mensal R$:");
		contentPane.add(lblNewLabel_1);
		
		JPanel panel = new JPanel();
		contentPane.add(panel);
		panel.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		
		depmen = new JTextField();
		panel.add(depmen);
		depmen.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Num. de meses");
		contentPane.add(lblNewLabel_3);
		
		JPanel panel_1 = new JPanel();
		contentPane.add(panel_1);
		panel_1.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		
		nmeses = new JTextField();
		panel_1.add(nmeses);
		nmeses.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Juros ao mês %:");
		contentPane.add(lblNewLabel_2);
		
		JPanel panel_2 = new JPanel();
		contentPane.add(panel_2);
		panel_2.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		
		jurosaomes = new JTextField();
		panel_2.add(jurosaomes);
		jurosaomes.setColumns(10);
		
		JLabel lblNewLabel_5 = new JLabel("Total investido + juros R$:");
		contentPane.add(lblNewLabel_5);
		
		JLabel lblNewLabel_4 = new JLabel("");
		contentPane.add(lblNewLabel_4);
		
		JLabel lblNewLabel = new JLabel("");
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("Calcular");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				i = Integer.parseInt(nmeses.getText());
				d = Double.parseDouble(jurosaomes.getText());
				k = Double.parseDouble(depmen.getText());
				Investimento investimento = new Investimento(i, d, k);
				lblNewLabel_4.setText(Double.toString(investimento.calculaTotal()));
			}
		});
		contentPane.add(btnNewButton);

	}

}
